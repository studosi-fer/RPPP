﻿namespace UnosDrzava
{


  partial class FirmaDataSet
  {
    }
}
